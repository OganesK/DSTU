import React from 'react';
import { Settings } from '@paljs/admin/Settings';

export default function SettingsPage() {
  return <Settings />;
}
