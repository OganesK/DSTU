export const SERVICE_NAME = 'template';
export const PORT = process.env.PORT || 3000;
export const HASH_SALT = process.env.HASH_SALT || 7;
export const JWT_SECRET = process.env.JWT_SECRET || 'change me';
