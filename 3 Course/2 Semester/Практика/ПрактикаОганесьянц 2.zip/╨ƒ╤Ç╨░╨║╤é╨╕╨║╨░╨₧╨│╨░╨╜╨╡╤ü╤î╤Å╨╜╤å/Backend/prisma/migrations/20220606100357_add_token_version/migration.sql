-- AlterTable
ALTER TABLE "User" ADD COLUMN     "tokenVersion" INTEGER;
