#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c='q';
    wchar_t wc=L'Q';
    printf("Ordinary variable: %d\n", sizeof c);
    wprintf(L"Wide variable: %d\n", sizeof wc);
    printf("Meanings: \n");
    putchar(c);
    putchar(wc);
    return 0;
}
