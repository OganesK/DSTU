#include <iostream>

using namespace std;

int main()
{
    char c='Q';
    wchar_t wc=L'q';
    cout<<"Ordinary variable: "<<c<<endl;
    wcout<<L"Wide variable: "<<wc<<endl;
    cout<<"Meanings: "<<endl;
    cout.put(c);
    cout.put(wc);
    return 0;
}
